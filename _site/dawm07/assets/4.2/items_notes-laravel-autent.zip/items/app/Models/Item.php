<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    use HasFactory;
    public $timestamps = false;  //turn off timestamps in migration.

    //fields fillable with mass create method.
    protected $fillable = ['title', 'content'];

    //relationship OneToMany between Item and Note
    public function notes() {
        //return $this->hasMany('App\Note');
        return $this->hasMany(Note::class);        
    }

    public function addNote(Note $note) {
        return $this->notes()->save($note);
    }
}
