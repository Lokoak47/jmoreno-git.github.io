<nav>
    <ul>
    <li><a href="/home">Home</a></li>
    <li><a href="/items">Items</a></li>
    <li><a href="/login">Login</a></li>
    <li><a href="/logout">Logout</a></li>
    </ul>
</nav>