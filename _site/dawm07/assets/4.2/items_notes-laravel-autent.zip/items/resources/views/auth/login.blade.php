@extends('layout')
 
@section('content')

<form method="post" action="{{ route('login.perform') }}">
    @csrf
    <h1 class="h3 mb-3 fw-normal">Login</h1>

    <div class="form-group mb-3">
        <label for="username">Email or Username</label>
        <input type="text" class="form-control" name="username" value="{{ old('username') }}" placeholder="Username" required="required" autofocus>
        @if ($errors->has('username'))
            <span class="text-danger text-left">{{ $errors->first('username') }}</span>
        @endif
    </div>
    
    <div class="form-group mb-3">
        <label for="password">Password</label>
        <input type="password" class="form-control" name="password" value="{{ old('password') }}" placeholder="Password" required="required">
        @if ($errors->has('password'))
            <span class="text-danger text-left">{{ $errors->first('password') }}</span>
        @endif
    </div>

    <div class="form-group mb-3">
        <label for="remember">Remember me</label>
        <input type="checkbox" name="remember" value="1">
    </div>

    <button class="w-100 btn btn-lg btn-primary" type="submit">Login</button>

</form>

@endsection