 
<?php $__env->startSection('content'); ?>

<form method="post" action="<?php echo e(route('login.perform')); ?>">
    <?php echo csrf_field(); ?>
    <h1 class="h3 mb-3 fw-normal">Login</h1>

    <div class="form-group mb-3">
        <label for="username">Email or Username</label>
        <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username" required="required" autofocus>
        <?php if($errors->has('username')): ?>
            <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
        <?php endif; ?>
    </div>
    
    <div class="form-group mb-3">
        <label for="password">Password</label>
        <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password" required="required">
        <?php if($errors->has('password')): ?>
            <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
        <?php endif; ?>
    </div>

    <div class="form-group mb-3">
        <label for="remember">Remember me</label>
        <input type="checkbox" name="remember" value="1">
    </div>

    <button class="w-100 btn btn-lg btn-primary" type="submit">Login</button>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumne/ws/php/items/resources/views/auth/login.blade.php ENDPATH**/ ?>