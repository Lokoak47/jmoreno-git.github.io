     
<?php $__env->startSection('content'); ?>
 
<?php if(empty($item)): ?>
    <p>No item found!</p>
<?php else: ?>
<form method="post" action="/items/<?php echo e($item->id); ?>/notes">
    <fieldset>
    <?php echo csrf_field(); ?>
    <div>
        <label for="id">Id:</label>
        <input type="text" name="id" value="<?php echo e($item->id); ?>"/>
    </div>
    <div>
        <label for="title">Title:</label>
        <input type="text" name="title" value="<?php echo e($item->title); ?>"/>
    </div>
    <div>
        <label for="content">Content:</label>
        <input type="text" name="content" value="<?php echo e($item->content); ?>"/>
    </div>
    </fieldset>
    <div>
    <b>Notes:</b>
    <ul>
        <?php $__currentLoopData = $item->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="/notes/<?php echo e($note->id); ?>/edit"><?php echo e($note->content); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>

<hr/>
<h3>Add a new note</h3>
<form method="post" action="/items/<?php echo e($item->id); ?>/notes">
    <div class="form-group">
        <textarea name="content" class="form-control"><?php echo e(old('content')); ?></textarea>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Add note</button>
    </div>
</form>
 
<?php if(count($errors)): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumne/ws/php/items/resources/views/item/form.blade.php ENDPATH**/ ?>