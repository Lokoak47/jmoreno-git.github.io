<?php $__env->startSection('content'); ?>

<?php if(empty($note)): ?>
    <p>No note found!</p>
<?php else: ?>
<hr/>
<h3>Edit a note</h3>
<form method="post" action="/notes/<?php echo e($note->id); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <textarea name="content" class="form-control"><?php echo e($note->content); ?></textarea>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Update note</button>
    </div>
</form>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumne/ws/php/items/resources/views/note/form.blade.php ENDPATH**/ ?>