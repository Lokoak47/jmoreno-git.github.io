<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ItemController;
use App\Http\Controllers\NoteController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\LogoutController;

Route::group(['middleware' => ['web']], function () {
    Route::get('/', function () {
        return view('welcome');
    });
    Route::get('/home', function () {
        return view('welcome');
    });
    Route::get('/items', function () {
        return view('item.index');
    });
    Route::get('/items/list', [ItemController::class, 'list']);
    Route::get('/items/{item}', [ItemController::class, 'find']);
    Route::post('/items/{item}/notes', [NoteController::class, 'store']);
    Route::get('/notes/{note}/edit', [NoteController::class, 'edit']);
    Route::post('/notes/{note}', [NoteController::class, 'update']);
});

Route::middleware(['auth'])->group(function () {
    Route::get('/logout', [LogoutController::class, 'perform'])->name('logout');
});

Route::middleware(['guest'])->group(function () {
    Route::get('/login', [LoginController::class, 'show'])->name('login.show');
    Route::post('/login', [LoginController::class, 'login'])->name('login.perform');
});